import React from 'react';
import { useLocation } from 'wouter';
import PageTransition from '@/components/page-transition';

const Home = () => {
  // Function to handle navigation with scroll reset
  const [, setLocation] = useLocation();
  
  const handleNavigation = (path: string) => {
    // First scroll to top
    window.scrollTo(0, 0);
    // Then navigate after a slight delay for animation
    setTimeout(() => {
      setLocation(path);
      // Add another scroll to top after navigation to ensure the new page starts from the top
      setTimeout(() => window.scrollTo(0, 0), 50);
    }, 300);
  };

  return (
    <PageTransition>
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {/* Your feature cards - make sure to use the handleNavigation function */}
        {/* For example: */}
        <div 
          className="card cursor-pointer" 
          onClick={() => handleNavigation('/credits')}
        >
          {/* Credits card content */}
          <h3>Credits</h3>
        </div>
        {/* Add your other cards here with the same navigation pattern */}
      </div>
    </PageTransition>
  );
};

export default Home;