import { Link } from "wouter";
import { Button } from "@/components/ui/button";
import {
  NavigationMenu,
  NavigationMenuContent,
  NavigationMenuItem,
  NavigationMenuLink,
  NavigationMenuList,
  NavigationMenuTrigger,
} from "@/components/ui/navigation-menu";
import {
  Beaker,
  Search,
  Camera,
  TestTube,
  Menu,
  Home,
  X,
  GitBranch,
  Code2,
  Calculator
} from "lucide-react";
import { useState } from "react";
import { motion, AnimatePresence } from "framer-motion";
import AlertButton from "@/components/alert-button";

export default function Navbar() {
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false);

  const menuItems = [
    { href: "/home", icon: Home, label: "Home" },
    { href: "/predict", icon: Beaker, label: "Process Predictor" },
    { href: "/research", icon: Search, label: "Research Scraper" },
    { href: "/equipment", icon: Camera, label: "Equipment Analyzer" },
    { href: "/chemical", icon: TestTube, label: "Chemical Safety Analyzer" },
    { href: "/property-estimation", icon: Calculator, label: "Property Estimation" },
    { href: "/block-diagram", icon: GitBranch, label: "Block Diagram Generator" },
  ];

  return (
    <header className="sticky top-0 z-50 w-full border-b bg-background/95 backdrop-blur supports-[backdrop-filter]:bg-background/60">
      <div className="container flex h-14 items-center">
        <div className="mr-4 flex">
          <Link href="/" className="mr-6 flex items-center space-x-2">
            <span className="hidden font-bold sm:inline-block">LabMate</span>
          </Link>
        </div>

        {/* Desktop Navigation */}
        <div className="hidden md:flex flex-1 overflow-x-auto">
          <NavigationMenu className="flex-1">
            <NavigationMenuList className="justify-start space-x-0 whitespace-nowrap">
              {menuItems.map((item) => (
                <NavigationMenuItem key={item.href} className="flex-shrink-0">
                  <Link href={item.href}>
                    <Button variant="ghost" className="h-9 px-2 text-xs">
                      <item.icon className="mr-1 h-4 w-4" />
                      {item.label}
                    </Button>
                  </Link>
                </NavigationMenuItem>
              ))}
            </NavigationMenuList>
          </NavigationMenu>
        </div>

        {/* Mobile Menu Button */}
        <div className="md:hidden flex flex-1 justify-end">
          <Button
            variant="ghost"
            size="icon"
            onClick={() => setMobileMenuOpen(!mobileMenuOpen)}
            className="h-9 w-9"
          >
            {mobileMenuOpen ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
          </Button>
        </div>

        {/* Alert Button */}
        <div className="flex items-center">
          <AlertButton />
        </div>
      </div>

      {/* Mobile Menu */}
      <AnimatePresence>
        {mobileMenuOpen && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            className="md:hidden overflow-hidden"
          >
            <div className="container pb-4 pt-2 flex flex-col space-y-2">
              {menuItems.map((item) => (
                <Link key={item.href} href={item.href}>
                  <Button variant="ghost" className="w-full justify-start">
                    <item.icon className="mr-2 h-4 w-4" />
                    {item.label}
                  </Button>
                </Link>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}