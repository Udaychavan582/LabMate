import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Calculator } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Calculator, Beaker, Atom, Thermometer, Scale, Droplet } from "lucide-react";
import { motion } from "framer-motion";
import { predictProcess } from "@/lib/gemini";

export default function PropertyEstimation() {
  const [smiles, setSmiles] = useState("");
  const [properties, setProperties] = useState<any>(null);
  const [loading, setLoading] = useState(false);

  const handleEstimate = async () => {
    setLoading(true);
    try {
      const query = `Analyze this SMILES structure and provide properties in this exact format:
      {
        "molecularWeight": "number in g/mol",
        "density": "number in g/cm³",
        "boilingPoint": "number in °C",
        "meltingPoint": "number in °C",
        "solubility": "description",
        "structure": "brief description"
      }
      SMILES: ${smiles}`;

      const result = await predictProcess(query);
      try {
        const parsed = JSON.parse(result.replace(/^```json\n|\n```$/g, ''));
        setProperties(parsed);
      } catch {
        setProperties({
          error: "Could not parse properties from response"
        });
      }
    } catch (error) {
      console.error('Error:', error);
      setProperties({ error: "Failed to estimate properties" });
    }
    setLoading(false);
  };

  const PropertyCard = ({ icon: Icon, title, value }: any) => (
    <motion.div
      initial={{ scale: 0.9, opacity: 0 }}
      animate={{ scale: 1, opacity: 1 }}
      transition={{ duration: 0.3 }}
    >
      <Card className="bg-gradient-to-br from-primary/5 to-primary/10 border-primary/20">
        <CardContent className="p-6 flex items-center gap-4">
          <div className="p-3 rounded-full bg-primary/10">
            <Icon className="w-6 h-6 text-primary" />
          </div>
          <div>
            <p className="text-sm text-muted-foreground">{title}</p>
            <p className="text-lg font-semibold">{value}</p>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  );

  return (
    <div className="max-w-4xl mx-auto p-6 space-y-8">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        animate={{ opacity: 1, y: 0 }}
        className="space-y-2"
      >
        <h1 className="text-3xl font-bold tracking-tight flex items-center gap-2">
          <Calculator className="w-8 h-8 text-primary" />
          Physical Property Estimation
        </h1>
        <p className="text-muted-foreground">
          Estimate physical properties of chemical compounds using AI-powered analysis
        </p>
      </motion.div>

      <div className="flex gap-4">
        <Input
          value={smiles}
          onChange={(e) => setSmiles(e.target.value)}
          placeholder="Enter SMILES notation"
          className="flex-1"
        />
        <Button 
          onClick={handleEstimate} 
          disabled={loading || !smiles}
          className="min-w-[120px]"
        >
          {loading ? "Analyzing..." : "Estimate"}
        </Button>
      </div>

      {properties && !properties.error && (
        <motion.div 
          className="grid grid-cols-1 md:grid-cols-2 gap-4"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ staggerChildren: 0.1 }}
        >
          <PropertyCard 
            icon={Scale} 
            title="Molecular Weight" 
            value={properties.molecularWeight} 
          />
          <PropertyCard 
            icon={Beaker} 
            title="Density" 
            value={properties.density} 
          />
          <PropertyCard 
            icon={Thermometer} 
            title="Boiling Point" 
            value={properties.boilingPoint} 
          />
          <PropertyCard 
            icon={Thermometer} 
            title="Melting Point" 
            value={properties.meltingPoint} 
          />
          <PropertyCard 
            icon={Droplet} 
            title="Solubility" 
            value={properties.solubility} 
          />
          <PropertyCard 
            icon={Atom} 
            title="Structure" 
            value={properties.structure} 
          />
        </motion.div>
      )}

      {properties?.error && (
        <Card className="border-destructive/50 bg-destructive/5">
          <CardContent className="p-6">
            <p className="text-destructive">{properties.error}</p>
          </CardContent>
        </Card>
      )}
    </div>
  );
}